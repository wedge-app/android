package com.example.a2021_wedge.MyPageFrag.Potato;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.a2021_wedge.R;

public class LevelupPotato1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_levelup_potato1);
    }
}